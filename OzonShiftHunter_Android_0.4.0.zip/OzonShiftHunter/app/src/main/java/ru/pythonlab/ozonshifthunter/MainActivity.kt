package ru.pythonlab.ozonshifthunter

import android.Manifest
import android.accessibilityservice.AccessibilityServiceInfo
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.accessibility.AccessibilityManager
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*
import ru.pythonlab.ozonshifthunter.core.KnownOperations
import java.time.DayOfWeek

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("hunter_settings", MODE_PRIVATE) }
    private val operations = KnownOperations.ALL
    private val weekdays = listOf(
        DayOfWeek.MONDAY to "Понедельник",
        DayOfWeek.TUESDAY to "Вторник",
        DayOfWeek.WEDNESDAY to "Среда",
        DayOfWeek.THURSDAY to "Четверг",
        DayOfWeek.FRIDAY to "Пятница",
        DayOfWeek.SATURDAY to "Суббота",
        DayOfWeek.SUNDAY to "Воскресенье"
    )
    private val weekdayModes = mutableMapOf<DayOfWeek, String>()
    private var statusView: TextView? = null
    private var logPreview: TextView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = 0xFF111318.toInt()
        window.navigationBarColor = 0xFF111318.toInt()
        buildScreen()
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    private fun serviceEnabled(): Boolean {
        val am = getSystemService(AccessibilityManager::class.java) ?: return false
        return am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
            .any { it.resolveInfo.serviceInfo.packageName == packageName }
    }

    private fun refreshStatus() {
        val s = SettingsStore.load(this)
        val saved = prefs.contains("operation")
        statusView?.text = buildString {
            append(if (serviceEnabled()) "✅ Служба специальных возможностей включена" else "❌ Служба выключена — включи её в настройках Android")
            append('\n').append(if (s.dryRun) "👁 Режим наблюдения: приложение ничего не нажимает" else "⚠ Нажатия разрешены (режим наблюдения выключен)")
            if (!saved) append("\n⚠ Настройки ещё ни разу не сохранены — нажми «Сохранить настройки»")
            else if (s.operation !in operations) append("\n⚠ Сохранённая операция «${s.operation}» не из списка — выбери операцию и сохрани настройки заново")
        }
        val tail = LogStore.tail(this, 6000).lines().takeLast(25).joinToString("\n")
        logPreview?.text = if (tail.isBlank()) "(лог пока пуст)" else tail
    }

    private fun buildScreen() {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 24)
            setBackgroundColor(0xFF111318.toInt())
        }
        val scroll = ScrollView(this).apply { fitsSystemWindows = true }
        scroll.addView(page)

        val title = TextView(this).apply {
            text = "Ozon Shift Hunter"
            textSize = 26f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
        }
        page.addView(title)
        page.addView(label("Настройка поиска"))

        val region = edit("Регион (например, Омск)", "region")
        val warehouse = edit("Склад (например, Омск РФЦ)", "warehouse")
        page.addView(region)
        page.addView(warehouse)

        page.addView(label("Операция"))
        val spinner = Spinner(this)
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, operations)
        val savedOperation = prefs.getString("operation", operations.first())
        val selectedIndex = operations.indexOf(savedOperation).coerceAtLeast(0)
        spinner.setSelection(selectedIndex)
        page.addView(spinner)

        page.addView(label("Подходящее время смены"))
        page.addView(info("Можно отметить один или оба интервала. Будут рассматриваться только выбранные варианты."))
        val day = CheckBox(this).apply {
            text = "08:00–20:00 (день)"
            textSize = 16f
            setTextColor(0xFFFFFFFF.toInt())
            isChecked = prefs.getBoolean("day", true)
        }
        val night = CheckBox(this).apply {
            text = "20:00–08:00 (ночь)"
            textSize = 16f
            setTextColor(0xFFFFFFFF.toInt())
            isChecked = prefs.getBoolean("night", false)
        }
        page.addView(day)
        page.addView(night)

        page.addView(label("Правила по дням недели"))
        page.addView(info("Для каждого дня выбери режим. В режиме «Только уведомление» приложение не должно нажимать «Записаться». Настройки пользователя имеют приоритет."))
        weekdays.forEach { (weekday, titleText) ->
            val savedMode = prefs.getString(BookingPolicy.keyFor(weekday), BookingPolicy.MODE_NOTIFY)
                ?: BookingPolicy.MODE_NOTIFY
            weekdayModes[weekday] = savedMode
            page.addView(weekdayRow(weekday, titleText, savedMode))
        }

        page.addView(label("Автоматизация"))
        val auto = CheckBox(this).apply {
            text = "Разрешить автоматическую запись"
            textSize = 16f
            setTextColor(0xFFFFFFFF.toInt())
            isChecked = prefs.getBoolean("auto", false)
        }
        val hot = CheckBox(this).apply {
            text = "Автозапись на горящую смену"
            textSize = 16f
            setTextColor(0xFFFFFFFF.toInt())
            isChecked = prefs.getBoolean("hot", false)
        }
        page.addView(auto)
        page.addView(hot)
        val dryRun = CheckBox(this).apply {
            text = "Режим наблюдения (ничего не нажимать)"
            textSize = 16f
            setTextColor(0xFFFFFFFF.toInt())
            isChecked = prefs.getBoolean("dry_run", true)
        }
        page.addView(dryRun)
        page.addView(info("Включён по умолчанию: служба только читает экран Ozon Job, пишет лог ShiftHunter и присылает уведомления. Пока в логе не подтверждено, что экраны распознаются верно, оставь включённым."))
        page.addView(info("Общий переключатель автозаписи должен быть включён, а день недели должен иметь режим «Автозапись». Иначе — только уведомление. Если включить автозапись только на горящие смены, зелёные будут приходить как уведомления. Жёлтые смены всегда игнорируются."))

        page.addView(label("Приоритеты смен"))
        page.addView(info("🔴 Красный — горящая смена (приоритет №1)"))
        page.addView(info("🟢 Зелёный — высокая вероятность (приоритет №2)"))
        page.addView(info("🟡 Жёлтый — игнорировать"))

        page.addView(label("Состояние"))
        statusView = info("…")
        page.addView(statusView)

        val save = Button(this).apply {
            text = "Сохранить настройки"
            setOnClickListener {
                if (!day.isChecked && !night.isChecked) {
                    Toast.makeText(this@MainActivity, "Выбери хотя бы один интервал времени", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                val editor = prefs.edit()
                    .putString("region", region.text.toString().trim())
                    .putString("warehouse", warehouse.text.toString().trim())
                    .putString("operation", spinner.selectedItem.toString())
                    .putBoolean("day", day.isChecked)
                    .putBoolean("night", night.isChecked)
                    .putBoolean("auto", auto.isChecked)
                    .putBoolean("hot", hot.isChecked)
                    .putBoolean("dry_run", dryRun.isChecked)
                weekdayModes.forEach { (weekday, mode) -> editor.putString(BookingPolicy.keyFor(weekday), mode) }
                editor.apply()
                Toast.makeText(this@MainActivity, "Настройки сохранены", Toast.LENGTH_SHORT).show()
                refreshStatus()
            }
        }
        page.addView(save)

        val access = Button(this).apply {
            text = "Открыть настройки службы Android"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        page.addView(access)

        page.addView(label("Журнал ShiftHunter"))
        page.addView(info("Если что-то не распознаётся — открой Ozon Job, пройди до календаря и окна выбора времени, затем нажми «Отправить лог» и пришли его. Скриншоты не нужны. Файл: ${LogStore.path(this)}"))
        logPreview = info("…").apply { textSize = 11f; setTextIsSelectable(true) }
        page.addView(logPreview)
        page.addView(Button(this).apply {
            text = "Обновить"
            setOnClickListener { refreshStatus() }
        })
        page.addView(Button(this).apply {
            text = "Отправить лог"
            setOnClickListener {
                val text = LogStore.tail(this@MainActivity)
                if (text.isBlank()) {
                    Toast.makeText(this@MainActivity, "Лог пуст", Toast.LENGTH_SHORT).show()
                } else {
                    val send = Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(Intent.EXTRA_SUBJECT, "ShiftHunter log")
                        putExtra(Intent.EXTRA_TEXT, text)
                    }
                    startActivity(Intent.createChooser(send, "Отправить лог"))
                }
            }
        })
        page.addView(Button(this).apply {
            text = "Копировать лог в буфер"
            setOnClickListener {
                val cm = getSystemService(ClipboardManager::class.java)
                cm.setPrimaryClip(ClipData.newPlainText("ShiftHunter log", LogStore.tail(this@MainActivity)))
                Toast.makeText(this@MainActivity, "Скопировано", Toast.LENGTH_SHORT).show()
            }
        })
        page.addView(Button(this).apply {
            text = "Очистить лог"
            setOnClickListener {
                LogStore.clear(this@MainActivity)
                refreshStatus()
            }
        })
        page.addView(Button(this).apply {
            text = "Сбросить историю записей (журнал защиты от повторов)"
            setOnClickListener {
                PrefsLedgerStorage.clear(this@MainActivity)
                Toast.makeText(this@MainActivity, "История сброшена. Перезапусти службу (выкл/вкл в настройках Android)", Toast.LENGTH_LONG).show()
            }
        })

        setContentView(scroll)
    }

    private fun weekdayRow(day: DayOfWeek, titleText: String, selectedMode: String): View {
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 8, 0, 8)
        }
        container.addView(TextView(this).apply {
            text = titleText
            textSize = 16f
            setTextColor(0xFFFFFFFF.toInt())
        })
        val choices = RadioGroup(this).apply {
            orientation = RadioGroup.VERTICAL
        }
        val autoId = View.generateViewId()
        val notifyId = View.generateViewId()
        choices.addView(RadioButton(this).apply {
            id = autoId
            text = "Автозапись"
            textSize = 13f
            setTextColor(0xFFFFFFFF.toInt())
            isChecked = selectedMode == BookingPolicy.MODE_AUTO
        })
        choices.addView(RadioButton(this).apply {
            id = notifyId
            text = "Только уведомление"
            textSize = 13f
            setTextColor(0xFFFFFFFF.toInt())
            isChecked = selectedMode == BookingPolicy.MODE_NOTIFY
        })
        val disabledId = View.generateViewId()
        choices.addView(RadioButton(this).apply {
            id = disabledId
            text = "Отключено"
            textSize = 13f
            setTextColor(0xFFFFFFFF.toInt())
            isChecked = selectedMode == BookingPolicy.MODE_DISABLED
        })
        choices.setOnCheckedChangeListener { _, checkedId ->
            weekdayModes[day] = when (checkedId) {
                autoId -> BookingPolicy.MODE_AUTO
                disabledId -> BookingPolicy.MODE_DISABLED
                else -> BookingPolicy.MODE_NOTIFY
            }
        }
        container.addView(choices)
        return container
    }

    private fun label(value: String) = TextView(this).apply {
        text = value; textSize = 18f; setTextColor(0xFF72A7FF.toInt())
        setPadding(0, 22, 0, 8)
    }

    private fun info(value: String) = TextView(this).apply {
        text = value; textSize = 14f; setTextColor(0xFFE5E7EB.toInt())
        setPadding(0, 7, 0, 7)
    }

    private fun edit(hintText: String, key: String) = EditText(this).apply {
        hint = hintText; setSingleLine(true); setTextColor(0xFFFFFFFF.toInt())
        setHintTextColor(0xFF9CA3AF.toInt())
        setText(prefs.getString(key, ""))
    }
}
