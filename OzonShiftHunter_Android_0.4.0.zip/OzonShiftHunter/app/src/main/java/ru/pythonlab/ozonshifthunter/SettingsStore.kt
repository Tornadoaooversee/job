package ru.pythonlab.ozonshifthunter

import android.content.Context
import ru.pythonlab.ozonshifthunter.core.HunterSettings
import ru.pythonlab.ozonshifthunter.core.LedgerStorage
import ru.pythonlab.ozonshifthunter.core.WeekdayMode
import java.time.DayOfWeek

/** Чтение пользовательских настроек из SharedPreferences в неизменяемый объект для ядра. */
object SettingsStore {
    const val PREFS = "hunter_settings"

    fun load(context: Context): HunterSettings {
        val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return HunterSettings(
            region = p.getString("region", "") ?: "",
            warehouse = p.getString("warehouse", "") ?: "",
            operation = p.getString("operation", "") ?: "",
            dayAllowed = p.getBoolean("day", true),
            nightAllowed = p.getBoolean("night", false),
            autoEnabled = p.getBoolean("auto", false),
            hotOnly = p.getBoolean("hot", false),
            weekdayModes = DayOfWeek.values().associateWith {
                when (p.getString(BookingPolicy.keyFor(it), BookingPolicy.MODE_NOTIFY)) {
                    BookingPolicy.MODE_AUTO -> WeekdayMode.AUTO
                    BookingPolicy.MODE_DISABLED -> WeekdayMode.DISABLED
                    else -> WeekdayMode.NOTIFY
                }
            },
            // По умолчанию — режим наблюдения: ничего не нажимаем, пока пользователь явно не выключит.
            dryRun = p.getBoolean("dry_run", true)
        )
    }
}

/** Журнал записей хранится в SharedPreferences и пишется синхронно (commit), чтобы пережить падение процесса. */
class PrefsLedgerStorage(context: Context) : LedgerStorage {
    private val prefs = context.getSharedPreferences("hunter_ledger", Context.MODE_PRIVATE)
    override fun load(): String = prefs.getString("data", "") ?: ""
    override fun save(data: String) {
        prefs.edit().putString("data", data).commit()
    }

    companion object {
        fun clear(context: Context) {
            context.getSharedPreferences("hunter_ledger", Context.MODE_PRIVATE).edit().clear().commit()
        }
    }
}
