package ru.pythonlab.ozonshifthunter

import android.graphics.Bitmap
import ru.pythonlab.ozonshifthunter.core.ColorClassifier
import ru.pythonlab.ozonshifthunter.core.ColorProbe
import ru.pythonlab.ozonshifthunter.core.PixelSource

/**
 * Accessibility tree не содержит цвета, поэтому красный/зелёный/жёлтый определяем по пикселям скриншота
 * (AccessibilityService.takeScreenshot, Android 11+). Если скриншот недоступен — цвет UNKNOWN,
 * а UNKNOWN политика никогда не пропускает в автозапись.
 */
object ScreenshotColorProbe {
    fun from(bitmap: Bitmap): ColorProbe {
        val src = object : PixelSource {
            override val width: Int get() = bitmap.width
            override val height: Int get() = bitmap.height
            override fun pixel(x: Int, y: Int): Int = bitmap.getPixel(x.coerceIn(0, bitmap.width - 1), y.coerceIn(0, bitmap.height - 1))
        }
        return { bounds -> ColorClassifier.analyzeRegion(src, bounds) }
    }
}
