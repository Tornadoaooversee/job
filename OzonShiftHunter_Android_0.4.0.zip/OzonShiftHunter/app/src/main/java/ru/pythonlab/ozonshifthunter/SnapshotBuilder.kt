package ru.pythonlab.ozonshifthunter

import android.graphics.Rect
import android.view.accessibility.AccessibilityNodeInfo
import ru.pythonlab.ozonshifthunter.core.Bounds
import ru.pythonlab.ozonshifthunter.core.ScreenSnapshot
import ru.pythonlab.ozonshifthunter.core.UiNode

/** Переводит живое дерево AccessibilityNodeInfo в неизменяемый снимок для чистого ядра. */
object SnapshotBuilder {
    const val MAX_NODES = 700
    const val MAX_DEPTH = 40

    /** Подпись узла ровно так, как её видит ядро ([UiNode.label]); нужна и при повторном поиске узла для клика. */
    fun labelOf(info: AccessibilityNodeInfo): String {
        val text = clean(info.text)
        return text.ifEmpty { clean(info.contentDescription) }
    }

    private fun clean(cs: CharSequence?): String = cs?.toString()?.replace('\n', ' ')?.trim().orEmpty()

    class Result(val snapshot: ScreenSnapshot, val skippedInvisible: Int)

    fun build(root: AccessibilityNodeInfo, packageName: String, extraTexts: List<String>, nowMs: Long): Result {
        val nodes = ArrayList<UiNode>()
        var truncated = false
        var invisible = 0
        val rect = Rect()

        fun walk(info: AccessibilityNodeInfo, parent: Int, depth: Int, path: List<Int>) {
            if (nodes.size >= MAX_NODES || depth > MAX_DEPTH) { truncated = true; return }
            // Невидимые узлы (соседние страницы ViewPager, скрытые вкладки) дублируют контент — пропускаем вместе с поддеревом.
            if (depth > 0 && !info.isVisibleToUser) { invisible++; return }
            info.getBoundsInScreen(rect)
            val idx = nodes.size
            nodes += UiNode(
                index = idx, parent = parent, depth = depth, path = path,
                className = info.className?.toString() ?: "",
                text = clean(info.text),
                desc = clean(info.contentDescription),
                viewId = info.viewIdResourceName ?: "",
                clickable = info.isClickable,
                enabled = info.isEnabled,
                selected = info.isSelected,
                checked = info.isChecked,
                checkable = info.isCheckable,
                bounds = Bounds(rect.left, rect.top, rect.right, rect.bottom)
            )
            for (i in 0 until info.childCount) {
                val child = info.getChild(i) ?: continue
                try {
                    walk(child, idx, depth + 1, path + i)
                } finally {
                    @Suppress("DEPRECATION") child.recycle()
                }
            }
        }

        walk(root, -1, 0, emptyList())
        return Result(ScreenSnapshot(packageName, nodes, nowMs, extraTexts, truncated), invisible)
    }

    /** Находит живой узел по пути от корня. Промежуточные узлы не рециклируем (в API 33+ recycle — no-op). */
    fun resolve(root: AccessibilityNodeInfo, path: List<Int>): AccessibilityNodeInfo? {
        var cur: AccessibilityNodeInfo = root
        for (i in path) {
            if (i >= cur.childCount) return null
            cur = cur.getChild(i) ?: return null
        }
        return cur
    }
}
