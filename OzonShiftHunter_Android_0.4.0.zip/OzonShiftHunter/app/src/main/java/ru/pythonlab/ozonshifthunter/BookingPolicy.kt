package ru.pythonlab.ozonshifthunter

import android.content.Context
import ru.pythonlab.ozonshifthunter.core.Decision
import ru.pythonlab.ozonshifthunter.core.PolicyEngine
import ru.pythonlab.ozonshifthunter.core.Priority
import ru.pythonlab.ozonshifthunter.core.ShiftCandidate
import ru.pythonlab.ozonshifthunter.core.ShiftInterval
import java.time.DayOfWeek
import java.time.LocalDate

/**
 * Тонкая обёртка над [PolicyEngine] для кода, которому нужен Context. Вся логика решений — в ядре
 * (core/Policy.kt) и покрыта тестами; здесь её нет, чтобы правила не разъезжались.
 */
object BookingPolicy {
    const val MODE_AUTO = "AUTO"
    const val MODE_NOTIFY = "NOTIFY"
    const val MODE_DISABLED = "DISABLED"

    fun keyFor(day: DayOfWeek): String = "weekday_mode_${day.name.lowercase()}"

    fun modeForDate(context: Context, date: LocalDate): String = SettingsStore.load(context).modeFor(date).name

    fun decide(context: Context, date: LocalDate, interval: ShiftInterval, priority: Priority): Decision =
        PolicyEngine.evaluate(SettingsStore.load(context), ShiftCandidate(date, interval, priority), LocalDate.now())

    fun canAutoBook(context: Context, date: LocalDate, isDayShift: Boolean, isHotShift: Boolean): Boolean =
        decide(context, date, if (isDayShift) ShiftInterval.DAY else ShiftInterval.NIGHT, if (isHotShift) Priority.RED else Priority.GREEN) is Decision.AutoBook

    fun shouldNotifyOnly(context: Context, date: LocalDate, isDayShift: Boolean, isHotShift: Boolean): Boolean =
        !canAutoBook(context, date, isDayShift, isHotShift)

    fun isTimeAllowed(context: Context, isDayShift: Boolean): Boolean =
        SettingsStore.load(context).intervalAllowed(if (isDayShift) ShiftInterval.DAY else ShiftInterval.NIGHT)
}
