package ru.pythonlab.ozonshifthunter.core

import java.time.LocalDate

enum class BookingState {
    /** Пользователь уведомлён (повторно не уведомляем). */
    NOTIFIED,
    /** Кнопка «Записаться» нажата, результат ещё неизвестен. Повторно НЕ нажимаем. */
    ATTEMPTED,
    /** Подтверждено. Никогда больше не трогаем. */
    BOOKED,
    /** Ozon принял заявку в очередь, но смена пока НЕ подтверждена. */
    WAITLISTED,
    /** Ozon явно ответил ошибкой. Повтор возможен ограниченно и не сразу. */
    FAILED,
    /** Нажали, но подтверждение не получили. Автоматических повторов нет — проверить вручную. */
    UNCERTAIN
}

data class ShiftKey(
    val date: LocalDate,
    val interval: ShiftInterval,
    val warehouse: String,
    val operation: String
) {
    fun id(): String = "$date|${interval.name}|${clean(warehouse)}|${clean(operation)}"
    override fun toString(): String = "$date ${interval.label}"

    companion object {
        private fun clean(s: String) = normalize(s).replace('|', ' ').replace('\n', ' ')
    }
}

data class LedgerEntry(val id: String, val date: LocalDate, val state: BookingState, val attempts: Int, val updatedMs: Long)

interface LedgerStorage {
    fun load(): String
    fun save(data: String)
}

/**
 * Защита от повторной записи. Состояние сохраняется СРАЗУ при каждом изменении, а ATTEMPTED
 * записывается ДО нажатия кнопки — поэтому даже падение процесса не приведёт к двойному клику.
 */
class BookingLedger(
    private val storage: LedgerStorage,
    private val clock: () -> Long
) {
    private val entries = LinkedHashMap<String, LedgerEntry>()

    init {
        load()
    }

    fun state(key: ShiftKey): BookingState? = entries[key.id()]?.state
    fun attempts(key: ShiftKey): Int = entries[key.id()]?.attempts ?: 0
    fun all(): List<LedgerEntry> = entries.values.toList()

    /** На эту дату уже есть запись (или возможная запись) — вторую смену в тот же день автоматически не берём. */
    fun hasActiveBookingOn(date: LocalDate): Boolean = entries.values.any {
        it.date == date && (it.state == BookingState.BOOKED || it.state == BookingState.WAITLISTED || it.state == BookingState.ATTEMPTED || it.state == BookingState.UNCERTAIN)
    }

    fun canNotify(key: ShiftKey): Boolean = entries[key.id()] == null

    /** Можно ли сейчас нажимать «Записаться» для этой смены. */
    fun canAttempt(key: ShiftKey): Boolean {
        val e = entries[key.id()] ?: return true
        return when (e.state) {
            BookingState.NOTIFIED -> true
            BookingState.FAILED -> e.attempts < MAX_ATTEMPTS && clock() - e.updatedMs >= RETRY_COOLDOWN_MS
            BookingState.ATTEMPTED, BookingState.BOOKED, BookingState.WAITLISTED, BookingState.UNCERTAIN -> false
        }
    }

    fun markNotified(key: ShiftKey) {
        if (entries[key.id()] == null) put(key, BookingState.NOTIFIED, 0)
    }

    fun markAttempted(key: ShiftKey) = put(key, BookingState.ATTEMPTED, attempts(key) + 1)
    fun markBooked(key: ShiftKey) = put(key, BookingState.BOOKED, attempts(key))
    fun markWaitlisted(key: ShiftKey) = put(key, BookingState.WAITLISTED, attempts(key))

    /**
     * Изменение статуса заявки, ранее принятой в очередь. Вызывать только при наличии
     * однозначного НОВОГО подтверждения в разделе записей Ozon Job.
     * Ни текст на экране выбора времени, ни отсутствие записи не являются подтверждением.
     */
    fun confirmWaitlisted(key: ShiftKey): Boolean {
        if (state(key) != BookingState.WAITLISTED) return false
        put(key, BookingState.BOOKED, attempts(key))
        return true
    }

    /** Без явного подтверждения состояние очереди остаётся неизменным. */
    fun observeWaitlist(key: ShiftKey, confirmed: Boolean): Boolean =
        if (confirmed) confirmWaitlisted(key) else false
    fun markFailed(key: ShiftKey) = put(key, BookingState.FAILED, attempts(key))
    fun markUncertain(key: ShiftKey) = put(key, BookingState.UNCERTAIN, attempts(key))

    fun reset() {
        entries.clear()
        persist()
    }

    /** Удалить записи по датам, которые давно прошли. */
    fun prune(today: LocalDate) {
        val before = entries.size
        entries.values.removeAll { it.date.isBefore(today.minusDays(7)) }
        if (entries.size != before) persist()
    }

    private fun put(key: ShiftKey, state: BookingState, attempts: Int) {
        entries[key.id()] = LedgerEntry(key.id(), key.date, state, attempts, clock())
        persist()
    }

    private fun persist() {
        storage.save(entries.values.joinToString("\n") { "${it.id}\t${it.state.name}\t${it.attempts}\t${it.updatedMs}" })
    }

    private fun load() {
        entries.clear()
        for (line in storage.load().lineSequence()) {
            val p = line.split('\t')
            if (p.size != 4) continue
            try {
                val id = p[0]
                val date = LocalDate.parse(id.substringBefore('|'))
                entries[id] = LedgerEntry(id, date, BookingState.valueOf(p[1]), p[2].toInt(), p[3].toLong())
            } catch (_: Exception) {
                // битая строка — пропускаем
            }
        }
    }

    companion object {
        const val MAX_ATTEMPTS = 2
        const val RETRY_COOLDOWN_MS = 10 * 60_000L
    }
}
