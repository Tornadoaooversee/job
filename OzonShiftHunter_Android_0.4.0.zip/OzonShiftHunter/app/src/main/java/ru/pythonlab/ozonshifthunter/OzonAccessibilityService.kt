package ru.pythonlab.ozonshifthunter

import android.accessibilityservice.AccessibilityService
import android.graphics.Bitmap
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import ru.pythonlab.ozonshifthunter.core.BookingLedger
import ru.pythonlab.ozonshifthunter.core.ColorProbe
import ru.pythonlab.ozonshifthunter.core.HunterMachine
import ru.pythonlab.ozonshifthunter.core.NO_COLOR
import ru.pythonlab.ozonshifthunter.core.Output
import ru.pythonlab.ozonshifthunter.core.ScreenDump
import ru.pythonlab.ozonshifthunter.core.ScreenParser
import ru.pythonlab.ozonshifthunter.core.ScreenSnapshot
import ru.pythonlab.ozonshifthunter.core.ScreenType
import ru.pythonlab.ozonshifthunter.core.UiNode
import java.time.LocalDate

/**
 * Служба-«проводник» между Android и чистым ядром:
 *  снимок дерева → [HunterMachine] → команды (лог, уведомление, клик, «Назад»).
 *
 * Содержимое читается ТОЛЬКО у приложений, чьё имя пакета содержит «ozon». Остальные приложения не
 * читаются и не логируются (кроме имени пакета при смене).
 * В режиме наблюдения (dry_run, включён по умолчанию) служба не выполняет ни одного клика.
 */
class OzonAccessibilityService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private var machine: HunterMachine? = null
    private var scheduled = false
    private var screenshotInFlight = false
    private var lastScreenshotAt = 0L
    private var lastDumpSig = ""
    private var lastDumpAt = 0L
    private var lastForeignPkg = ""
    private val pendingExtra = ArrayList<String>()
    private val processRunnable = Runnable { scheduled = false; processScreen() }

    override fun onServiceConnected() {
        super.onServiceConnected()
        val ledger = BookingLedger(PrefsLedgerStorage(this)) { System.currentTimeMillis() }
        machine = HunterMachine({ SettingsStore.load(this) }, ledger, { System.currentTimeMillis() }, { LocalDate.now() })
        val s = SettingsStore.load(this)
        LogStore.log(this, "SERVICE подключена. sdk=${Build.VERSION.SDK_INT} dryRun=${s.dryRun} auto=${s.autoEnabled} hotOnly=${s.hotOnly} " +
            "day=${s.dayAllowed} night=${s.nightAllowed} склад=\"${s.warehouse}\" операция=\"${s.operation}\" " +
            "дни=${s.weekdayModes.entries.joinToString { it.key.name.take(3) + ":" + it.value.name }}")
        instance = this
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        LogStore.log(this, "SERVICE отключена")
        if (instance === this) instance = null
        return super.onUnbind(intent)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val pkg = event.packageName?.toString().orEmpty()
        if (!ScreenParser.defaultPackageFilter(pkg)) {
            // Чужие приложения: содержимое не читаем. Сообщаем машине только при смене пакета.
            if (pkg.isNotEmpty() && pkg != lastForeignPkg && event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED &&
                pkg != packageName && !pkg.startsWith("com.android.systemui")
            ) {
                lastForeignPkg = pkg
                LogStore.log(this, "FOREIGN pkg=$pkg (содержимое не читается)")
                machine?.let { execute(it.onSnapshot(ScreenSnapshot(pkg, emptyList(), System.currentTimeMillis()))) }
            }
            return
        }
        lastForeignPkg = ""
        if (event.eventType == AccessibilityEvent.TYPE_NOTIFICATION_STATE_CHANGED) {
            // Toast приходит событием, а не узлом дерева.
            event.text.forEach { t -> t?.toString()?.takeIf { it.isNotBlank() }?.let { pendingExtra += it } }
            while (pendingExtra.size > 5) pendingExtra.removeAt(0)
        }
        if (!scheduled) {
            scheduled = true
            handler.postDelayed(processRunnable, DEBOUNCE_MS)
        }
    }

    private fun processScreen() {
        val m = machine ?: return
        val root = rootInActiveWindow ?: return
        val snap: ScreenSnapshot? = try {
            val pkg = root.packageName?.toString().orEmpty()
            if (!ScreenParser.defaultPackageFilter(pkg)) {
                null
            } else {
                val extras = pendingExtra.toList()
                pendingExtra.clear()
                val built = SnapshotBuilder.build(root, pkg, extras, System.currentTimeMillis())
                dumpIfChanged(built.snapshot, built.skippedInvisible)
                built.snapshot
            }
        } catch (e: Exception) {
            LogStore.log(this, "ERROR чтение дерева: $e")
            null
        } finally {
            @Suppress("DEPRECATION") root.recycle()
        }
        if (snap == null) return

        val needColors = ScreenParser.classify(snap) == ScreenType.CALENDAR
        val now = SystemClock.elapsedRealtime()
        if (needColors && Build.VERSION.SDK_INT >= Build.VERSION_CODES.R && !screenshotInFlight && now - lastScreenshotAt > SCREENSHOT_GAP_MS) {
            captureThenFeed(snap)
        } else {
            feed(m, snap, NO_COLOR)
        }
    }

    private fun captureThenFeed(snap: ScreenSnapshot) {
        val m = machine ?: return
        screenshotInFlight = true
        lastScreenshotAt = SystemClock.elapsedRealtime()
        try {
            takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : AccessibilityService.TakeScreenshotCallback {
                override fun onSuccess(screenshot: AccessibilityService.ScreenshotResult) {
                    var bmp: Bitmap? = null
                    try {
                        val hw = Bitmap.wrapHardwareBuffer(screenshot.hardwareBuffer, screenshot.colorSpace)
                        bmp = hw?.copy(Bitmap.Config.ARGB_8888, false)
                        hw?.recycle()
                    } catch (e: Exception) {
                        LogStore.log(this@OzonAccessibilityService, "SCREENSHOT ошибка обработки: $e")
                    } finally {
                        screenshot.hardwareBuffer.close()
                    }
                    screenshotInFlight = false
                    val probe: ColorProbe = bmp?.let { ScreenshotColorProbe.from(it) } ?: NO_COLOR
                    feed(m, snap, probe)
                    bmp?.recycle()
                }

                override fun onFailure(errorCode: Int) {
                    screenshotInFlight = false
                    LogStore.log(this@OzonAccessibilityService, "SCREENSHOT недоступен (код $errorCode) → цвета UNKNOWN, автозапись невозможна")
                    feed(m, snap, NO_COLOR)
                }
            })
        } catch (e: Exception) {
            screenshotInFlight = false
            LogStore.log(this, "SCREENSHOT исключение: $e")
            feed(m, snap, NO_COLOR)
        }
    }

    private fun feed(m: HunterMachine, snap: ScreenSnapshot, probe: ColorProbe) {
        try {
            execute(m.onSnapshot(snap, probe))
        } catch (e: Exception) {
            // Любая неожиданность в ядре = полный сброс и тишина, а не продолжение «на удачу».
            LogStore.log(this, "ERROR машина: $e → сброс")
            m.reset()
        }
    }

    private fun execute(outputs: List<Output>) {
        for (o in outputs) when (o) {
            is Output.Log -> LogStore.log(this, o.message)
            is Output.Notify -> Notifier.post(this, o.title, o.text, o.dedupeId)
            is Output.Back -> {
                val ok = performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK)
                LogStore.log(this, "ACTION back ok=$ok")
            }
            is Output.Click -> {
                val err = performClick(o.node)
                if (err != null) {
                    // Клик не выполнен — сообщаем машине (она сама решит, что отменить).
                    machine?.let { execute(it.onClickFailed(err)) }
                } else {
                    LogStore.log(this, "ACTION click выполнен [${o.purpose}]")
                }
            }
        }
    }

    /** Возвращает null при успехе, иначе причину отказа. Перед кликом узел находится заново и сверяется по подписи. */
    private fun performClick(expected: UiNode): String? {
        if (SettingsStore.load(this).dryRun) return "режим наблюдения"
        val root = rootInActiveWindow ?: return "нет активного окна"
        val pkg = root.packageName?.toString().orEmpty()
        if (!ScreenParser.defaultPackageFilter(pkg)) return "активно другое приложение ($pkg)"
        val live = SnapshotBuilder.resolve(root, expected.path) ?: return "узел по пути ${expected.path} не найден"
        val label = SnapshotBuilder.labelOf(live)
        if (label != expected.label) return "подпись узла изменилась: было «${expected.label}», стало «$label»"
        if (!live.isEnabled) return "узел отключён"
        val ok = live.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        return if (ok) null else "performAction(CLICK) вернул false"
    }

    private fun dumpIfChanged(snap: ScreenSnapshot, skippedInvisible: Int) {
        val sig = ScreenDump.signature(snap)
        val now = SystemClock.elapsedRealtime()
        if (sig == lastDumpSig || now - lastDumpAt < DUMP_GAP_MS) return
        lastDumpSig = sig
        lastDumpAt = now
        LogStore.log(this, "DUMP pkg=${snap.packageName} nodes=${snap.nodes.size} невидимых_пропущено=$skippedInvisible" +
            (if (snap.truncated) " УСЕЧЕНО" else "") + (if (snap.extraTexts.isNotEmpty()) " extra=${snap.extraTexts}" else ""))
        ScreenDump.lines(snap).forEach { LogStore.log(this, "  $it") }
    }

    override fun onInterrupt() = Unit

    companion object {
        private const val DEBOUNCE_MS = 350L
        private const val SCREENSHOT_GAP_MS = 1_200L
        private const val DUMP_GAP_MS = 2_500L

        @Volatile
        var instance: OzonAccessibilityService? = null
            private set
    }
}
