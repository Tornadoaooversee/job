package ru.pythonlab.ozonshifthunter.core

import java.time.DayOfWeek
import java.time.LocalDate

/*
 * Чистое ядро (без android.*): модели, парсинг экранов, политика, журнал записей и state machine.
 * Всё, что здесь лежит, проверяется обычными JVM-тестами без телефона.
 */

/** Приоритет смены: красный — горящая, зелёный — высокая вероятность, жёлтый — игнорировать. */
enum class Priority(val rank: Int, val icon: String) {
    RED(0, "🔴"), GREEN(1, "🟢"), WHITE(2, "⚪"), UNKNOWN(99, "❔"), YELLOW(100, "🟡")
}

enum class ShiftInterval(val label: String) {
    DAY("08:00–20:00"),
    NIGHT("20:00–08:00");

    companion object {
        fun fromTimes(startH: Int, startM: Int, endH: Int, endM: Int): ShiftInterval? = when {
            startM != 0 || endM != 0 -> null
            startH == 8 && endH == 20 -> DAY
            startH == 20 && endH == 8 -> NIGHT
            else -> null
        }
    }
}

/** 16 операций Ozon Job по скриншотам (docs/SCREENSHOT_FINDINGS.md). Названия должны совпадать с экраном. */
object KnownOperations {
    val ALL = listOf(
        "Сортировка мелкого товара", "Обработка проблемного товара", "Замена тары на автосортере",
        "Производство непрофиль", "Сортировка непрофиль", "Сортировка на автосортере",
        "Погрузка и разгрузка", "Подбор возвратов", "Инвентаризация", "Консолидация",
        "Размещение", "Подбор", "Приемка", "Упаковка", "Сортировка крупного товара", "Возвраты"
    )
}

enum class WeekdayMode { AUTO, NOTIFY, DISABLED }

/** Все пользовательские параметры одним неизменяемым объектом. */
data class HunterSettings(
    val region: String = "",
    val warehouse: String = "",
    val operation: String = "",
    val dayAllowed: Boolean = true,
    val nightAllowed: Boolean = false,
    val autoEnabled: Boolean = false,
    val hotOnly: Boolean = false,
    val weekdayModes: Map<DayOfWeek, WeekdayMode> = emptyMap(),
    /** true — сервис ничего не нажимает, только наблюдает, пишет лог и уведомляет. */
    val dryRun: Boolean = true
) {
    fun modeFor(date: LocalDate): WeekdayMode = weekdayModes[date.dayOfWeek] ?: WeekdayMode.NOTIFY
    fun intervalAllowed(interval: ShiftInterval): Boolean =
        if (interval == ShiftInterval.DAY) dayAllowed else nightAllowed
}

data class Bounds(val left: Int, val top: Int, val right: Int, val bottom: Int) {
    val width: Int get() = right - left
    val height: Int get() = bottom - top
    val centerX: Int get() = (left + right) / 2
    val centerY: Int get() = (top + bottom) / 2
    val isEmpty: Boolean get() = width <= 0 || height <= 0
}

/** Неизменяемая копия одного узла Accessibility tree. [path] — индексы детей от корня. */
data class UiNode(
    val index: Int,
    val parent: Int,
    val depth: Int,
    val path: List<Int>,
    val className: String = "",
    val text: String = "",
    val desc: String = "",
    val viewId: String = "",
    val clickable: Boolean = false,
    val enabled: Boolean = true,
    val selected: Boolean = false,
    val checked: Boolean = false,
    val checkable: Boolean = false,
    val bounds: Bounds = Bounds(0, 0, 0, 0)
) {
    /** Текст, а если его нет — contentDescription. */
    val label: String get() = text.ifEmpty { desc }
    val isToggleLike: Boolean
        get() = checkable || className.contains("CheckBox", true) ||
            className.contains("RadioButton", true) || className.contains("Switch", true)
}

/** Снимок экрана: плоский список узлов в порядке обхода дерева. */
class ScreenSnapshot(
    val packageName: String,
    val nodes: List<UiNode>,
    val timeMs: Long,
    /** Тексты, пришедшие не из дерева (например, Toast через событие). */
    val extraTexts: List<String> = emptyList(),
    val truncated: Boolean = false
) {
    private val childrenOf: Map<Int, List<UiNode>> by lazy { nodes.groupBy { it.parent } }

    fun children(index: Int): List<UiNode> = childrenOf[index].orEmpty()

    fun descendants(index: Int): List<UiNode> {
        val out = ArrayList<UiNode>()
        val stack = java.util.ArrayDeque<Int>()
        stack.addLast(index)
        while (stack.isNotEmpty()) {
            val cur = stack.removeLast()
            for (c in children(cur)) {
                out += c
                stack.addLast(c.index)
            }
        }
        return out
    }

    fun parentOf(node: UiNode): UiNode? = if (node.parent in nodes.indices) nodes[node.parent] else null

    fun ancestorsAndSelf(node: UiNode): Sequence<UiNode> = generateSequence(node) { parentOf(it) }

    /** Ближайший кликабельный узел (сам узел или предок). */
    fun clickTarget(node: UiNode): UiNode? = ancestorsAndSelf(node).firstOrNull { it.clickable }

    fun allLabels(): List<String> = nodes.map { it.label }.filter { it.isNotBlank() } + extraTexts
}

enum class ScreenType { NOT_OZON, UNKNOWN, CALENDAR, TIME_PICKER }

enum class BookingResult { SUCCESS, WAITLISTED, ERROR }

/** Нормализация строк для сравнения: нижний регистр, ё→е, схлопнутые пробелы. */
fun normalize(s: String): String =
    s.lowercase().replace('ё', 'е').replace(' ', ' ').replace(Regex("\\s+"), " ").trim()
