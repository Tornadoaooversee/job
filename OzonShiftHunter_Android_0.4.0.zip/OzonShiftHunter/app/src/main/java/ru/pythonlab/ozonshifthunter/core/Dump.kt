package ru.pythonlab.ozonshifthunter.core

/** Текстовый дамп дерева для лога: пользователь может прислать его вместо скриншотов. */
object ScreenDump {
    const val MAX_LINES = 220

    fun lines(snap: ScreenSnapshot): List<String> {
        val out = ArrayList<String>()
        for (n in snap.nodes) {
            val interesting = n.text.isNotEmpty() || n.desc.isNotEmpty() || n.viewId.isNotEmpty() || n.clickable || n.isToggleLike
            if (!interesting) continue
            if (out.size >= MAX_LINES) { out += "… усечено, всего узлов ${snap.nodes.size}"; break }
            out += "N${n.index} p=${n.parent} d=${n.depth} path=${n.path.joinToString("/")} ${n.className.substringAfterLast('.')} " +
                "text=\"${n.text}\" desc=\"${n.desc}\" id=${n.viewId} " +
                "clk=${n.clickable} en=${n.enabled} sel=${n.selected} chk=${n.checked} chkable=${n.checkable} " +
                "b=${n.bounds.left},${n.bounds.top},${n.bounds.right},${n.bounds.bottom}"
        }
        return out
    }

    /** Подпись «структуры» экрана без координат: меняется, когда меняются тексты/состояния. */
    fun signature(snap: ScreenSnapshot): String =
        snap.packageName + "|" + snap.nodes.joinToString("|") { "${it.label}#${it.selected}${it.checked}${it.enabled}" }.hashCode()
}
