package ru.pythonlab.ozonshifthunter

import android.content.Context
import android.util.Log
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Журнал ShiftHunter: пишется в файл (и в Logcat, тег ShiftHunter), чтобы пользователь мог прислать лог
 * без скриншотов и без Android Studio. Файл лежит в app-specific папке:
 * Android/data/ru.pythonlab.ozonshifthunter/files/shifthunter.log (доступен через adb pull).
 */
object LogStore {
    private const val TAG = "ShiftHunter"
    private const val FILE = "shifthunter.log"
    private const val MAX_BYTES = 1_500_000L
    private const val KEEP_BYTES = 900_000L
    private val lock = Any()
    private val fmt = SimpleDateFormat("MM-dd HH:mm:ss.SSS", Locale.US)

    private fun file(context: Context): File {
        val dir = context.getExternalFilesDir(null) ?: context.filesDir
        return File(dir, FILE)
    }

    fun path(context: Context): String = file(context).absolutePath

    fun log(context: Context, message: String) {
        Log.i(TAG, message)
        synchronized(lock) {
            try {
                val f = file(context)
                if (f.length() > MAX_BYTES) trim(f)
                f.appendText("${fmt.format(Date())} $message\n", Charsets.UTF_8)
            } catch (e: Exception) {
                Log.e(TAG, "не удалось записать лог", e)
            }
        }
    }

    private fun trim(f: File) {
        val bytes = f.readBytes()
        val from = (bytes.size - KEEP_BYTES).toInt().coerceAtLeast(0)
        val tail = String(bytes, from, bytes.size - from, Charsets.UTF_8)
        f.writeText("… (начало лога обрезано)\n" + tail.substringAfter('\n'), Charsets.UTF_8)
    }

    /** Хвост лога для отправки/копирования (в символах). */
    fun tail(context: Context, maxChars: Int = 100_000): String = synchronized(lock) {
        try {
            val f = file(context)
            if (!f.exists()) return ""
            val text = f.readText(Charsets.UTF_8)
            if (text.length <= maxChars) text else "… (показан хвост)\n" + text.substring(text.length - maxChars).substringAfter('\n')
        } catch (e: Exception) {
            "ошибка чтения лога: $e"
        }
    }

    fun clear(context: Context) = synchronized(lock) { runCatching { file(context).delete() }; Unit }
}
