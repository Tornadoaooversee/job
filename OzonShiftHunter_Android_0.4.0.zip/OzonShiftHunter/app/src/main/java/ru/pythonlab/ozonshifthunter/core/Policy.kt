package ru.pythonlab.ozonshifthunter.core

import java.time.LocalDate

data class ShiftCandidate(
    val date: LocalDate,
    val interval: ShiftInterval,
    val priority: Priority
)

/** Решение политики по одной смене. */
sealed class Decision {
    abstract val reason: String

    /** Смена не нужна: ни уведомления, ни записи. */
    data class Ignore(override val reason: String) : Decision()

    /** Только уведомить, не нажимать «Записаться». */
    data class NotifyOnly(override val reason: String) : Decision()

    /** Политика разрешает автозапись (фактическое нажатие ещё зависит от режима наблюдения и журнала). */
    data class AutoBook(override val reason: String) : Decision()
}

/**
 * Единственное место, где решается «можно ли писаться». Порядок проверок важен:
 * пользовательские параметры (интервал, день недели, переключатели) выше цвета.
 */
object PolicyEngine {
    fun evaluate(s: HunterSettings, c: ShiftCandidate, today: LocalDate): Decision {
        if (c.date.isBefore(today)) return Decision.Ignore("дата в прошлом")
        if (c.priority == Priority.YELLOW) return Decision.Ignore("жёлтая смена игнорируется")
        if (s.modeFor(c.date) == WeekdayMode.DISABLED) return Decision.Ignore("день недели отключён пользователем")
        if (!s.intervalAllowed(c.interval)) return Decision.Ignore("интервал ${c.interval.label} не выбран пользователем")

        // Цвет не определён → никогда не пишемся автоматически, только уведомляем.
        if (c.priority == Priority.UNKNOWN) return Decision.NotifyOnly("цвет смены не определён — автозапись запрещена")
        if (!s.autoEnabled) return Decision.NotifyOnly("общий переключатель автозаписи выключен")
        if (s.modeFor(c.date) != WeekdayMode.AUTO) return Decision.NotifyOnly("день недели в режиме «Только уведомление»")
        if (s.hotOnly && c.priority != Priority.RED) return Decision.NotifyOnly("включён режим «только горящие», смена не красная")
        return Decision.AutoBook("все условия автозаписи выполнены")
    }
}
