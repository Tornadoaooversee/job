package ru.pythonlab.ozonshifthunter.core

/** Источник пикселей (на Android — скриншот, в тестах — синтетика). */
interface PixelSource {
    val width: Int
    val height: Int
    fun pixel(x: Int, y: Int): Int // ARGB
}

data class ColorAnalysis(
    val priority: Priority,
    /** Средний цвет «цветных» пикселей, ARGB; null если цветных пикселей нет. */
    val dominantArgb: Int?,
    val colorfulShare: Double
) {
    fun hex(): String = dominantArgb?.let { "#%06X".format(it and 0xFFFFFF) } ?: "-"
}

/**
 * Accessibility tree НЕ содержит цвета. Приоритет смены определяется по пикселям скриншота.
 * Пороги — предположения, их нужно проверять по логу с реального экрана (в лог пишется hex цвета).
 */
object ColorClassifier {
    fun classify(argb: Int): Priority {
        val r = (argb shr 16) and 0xFF
        val g = (argb shr 8) and 0xFF
        val b = argb and 0xFF
        val max = maxOf(r, g, b)
        val min = minOf(r, g, b)
        val v = max / 255.0
        val s = if (max == 0) 0.0 else (max - min).toDouble() / max
        if (s < 0.40 || v < 0.45) return Priority.UNKNOWN // белый/серый/чёрный/блёклый — не сигнал
        val d = (max - min).toDouble()
        var h = when (max) {
            r -> 60 * (((g - b) / d) % 6)
            g -> 60 * (((b - r) / d) + 2)
            else -> 60 * (((r - g) / d) + 4)
        }
        if (h < 0) h += 360.0
        return when {
            h <= 18 || h >= 335 -> Priority.RED
            h in 38.0..68.0 -> Priority.YELLOW
            h in 85.0..165.0 -> Priority.GREEN
            else -> Priority.UNKNOWN // оранжевый/голубой/синий/фиолетовый — неоднозначно
        }
    }

    /**
     * Сетка проб внутри [bounds]. Нейтральные пиксели отбрасываются, цвет присваивается только если
     * не менее 60% цветных проб согласны и цветных проб хватает (≥ 15% от всех).
     */
    fun analyzeRegion(src: PixelSource, bounds: Bounds, grid: Int = 7): ColorAnalysis {
        if (src.width <= 0 || src.height <= 0 || grid <= 0) return ColorAnalysis(Priority.UNKNOWN, null, 0.0)
        if (bounds.right <= 0 || bounds.bottom <= 0 || bounds.left >= src.width || bounds.top >= src.height) {
            return ColorAnalysis(Priority.UNKNOWN, null, 0.0)
        }
        val l = bounds.left.coerceIn(0, src.width - 1)
        val r = bounds.right.coerceIn(0, src.width)
        val t = bounds.top.coerceIn(0, src.height - 1)
        val bt = bounds.bottom.coerceIn(0, src.height)
        if (r - l < 2 || bt - t < 2) return ColorAnalysis(Priority.UNKNOWN, null, 0.0)
        val counts = HashMap<Priority, Int>()
        var total = 0
        var sr = 0L; var sg = 0L; var sb = 0L; var colorful = 0
        for (iy in 0 until grid) for (ix in 0 until grid) {
            val x = l + ((r - l - 1) * (ix + 0.5) / grid).toInt()
            val y = t + ((bt - t - 1) * (iy + 0.5) / grid).toInt()
            val p = src.pixel(x, y)
            total++
            val pr = classify(p)
            if (pr != Priority.UNKNOWN) {
                counts[pr] = (counts[pr] ?: 0) + 1
                colorful++
                sr += (p shr 16) and 0xFF; sg += (p shr 8) and 0xFF; sb += p and 0xFF
            }
        }
        if (colorful == 0) return ColorAnalysis(Priority.UNKNOWN, null, 0.0)
        val share = colorful.toDouble() / total
        val avg = (0xFF shl 24) or ((sr / colorful).toInt() shl 16) or ((sg / colorful).toInt() shl 8) or (sb / colorful).toInt()
        val best = counts.maxByOrNull { it.value }!!
        val agree = best.value.toDouble() / colorful
        val pr = if (share >= 0.15 && agree >= 0.6) best.key else Priority.UNKNOWN
        return ColorAnalysis(pr, avg, share)
    }
}
