package ru.pythonlab.ozonshifthunter.core

import java.time.DayOfWeek
import java.time.LocalDate
import java.time.YearMonth

/** Описание узла для построения синтетического Accessibility tree. */
class N(
    val cls: String = "android.view.View",
    val text: String = "",
    val desc: String = "",
    val clickable: Boolean = false,
    val selected: Boolean = false,
    val checked: Boolean = false,
    val checkable: Boolean = false,
    val enabled: Boolean = true,
    val bounds: Bounds = Bounds(0, 0, 100, 100),
    val children: List<N> = emptyList()
)

fun buildSnapshot(root: N, pkg: String = "ru.ozon.job", extra: List<String> = emptyList(), timeMs: Long = 0L): ScreenSnapshot {
    val nodes = ArrayList<UiNode>()
    fun walk(n: N, parent: Int, depth: Int, path: List<Int>) {
        val idx = nodes.size
        nodes += UiNode(idx, parent, depth, path, n.cls, n.text, n.desc, "", n.clickable, n.enabled, n.selected, n.checked, n.checkable, n.bounds)
        n.children.forEachIndexed { i, c -> walk(c, idx, depth + 1, path + i) }
    }
    walk(root, -1, 0, emptyList())
    return ScreenSnapshot(pkg, nodes, timeMs, extra)
}

/**
 * Простой симулятор приложения Ozon Job: календарь → «Выбрать время» → выбор интервалов → «Записаться».
 * Тексты и структура — ПРЕДПОЛОЖЕНИЕ, соответствующее описанию пользователя.
 */
class FakeOzon(
    val month: YearMonth = YearMonth.of(2026, 11),
    /** день → подпись приоритета, которую приложение (предположительно) кладёт в описание ячейки */
    val dayLabels: Map<Int, String> = emptyMap(),
    val intervals: List<ShiftInterval> = listOf(ShiftInterval.DAY, ShiftInterval.NIGHT)
) {
    enum class Screen { CALENDAR, PICKER, RESULT }

    var screen = Screen.CALENDAR
    var selectedDay: Int? = null
    val checked = HashMap<ShiftInterval, Boolean>()
    var warehouse = "Омск РФЦ"
    var operation = "Производство непрофиль"

    // Режимы «поломки» для проверки защит
    var exposeSelected = true
    var exposeChecked = true
    var selectOffByOne = false
    var resultMode = "success" // success | none | error
    var calendarUnderSheet = false
    var bookEnabled = true

    /** Время снимка, как в реальной службе (машина не принимает подтверждение со снимка, сделанного до клика). */
    var clock: () -> Long = { 0L }

    val clicks = ArrayList<String>()
    var backs = 0
    var bookClicks = 0

    fun snapshot(): ScreenSnapshot {
        val kids = ArrayList<N>()
        when (screen) {
            Screen.RESULT -> {
                kids += N("android.widget.TextView", text = if (resultMode == "error") "Не удалось записаться" else "Вы записаны на смену")
            }
            Screen.PICKER -> {
                if (calendarUnderSheet) kids += calendarNodes()
                kids += pickerNodes()
            }
            Screen.CALENDAR -> kids += calendarNodes()
        }
        return buildSnapshot(N(children = kids), timeMs = clock())
    }

    private fun calendarNodes(): List<N> {
        val out = ArrayList<N>()
        out += N("android.widget.TextView", text = warehouse)
        out += N("android.widget.TextView", text = operation)
        out += N("android.widget.TextView", text = "Ноябрь 2026")
        val offset = month.atDay(1).dayOfWeek.value - 1
        for (d in 1..month.lengthOfMonth()) {
            val pos = offset + d - 1
            val label = dayLabels[d]?.let { ", $it" } ?: ""
            out += N(
                "android.view.View", desc = "$d ноября$label", clickable = true,
                selected = exposeSelected && selectedDay == d,
                bounds = Bounds((pos % 7) * 100, 300 + (pos / 7) * 100, (pos % 7) * 100 + 100, 400 + (pos / 7) * 100),
                children = listOf(N("android.widget.TextView", text = d.toString(), bounds = Bounds((pos % 7) * 100, 300 + (pos / 7) * 100, (pos % 7) * 100 + 100, 400 + (pos / 7) * 100)))
            )
        }
        if (selectedDay != null) out += N("android.widget.Button", text = "Выбрать время", clickable = true)
        return out
    }

    private fun pickerNodes(): List<N> {
        val rows = intervals.map { iv ->
            N("android.widget.LinearLayout", clickable = true, children = listOf(
                N("android.widget.TextView", text = iv.label),
                N("android.widget.CheckBox", checkable = true, checked = exposeChecked && checked[iv] == true, clickable = true)
            ))
        }
        return listOf(N("android.widget.LinearLayout", children = rows + N("android.widget.Button", text = "Записаться", clickable = true, enabled = bookEnabled)))
    }

    /** Эмуляция нажатия: ищем узел по path, сверяем подпись (как это делает сервис), применяем действие. */
    fun click(node: UiNode): Boolean {
        val live = snapshot().nodes.firstOrNull { it.path == node.path } ?: return false
        if (live.label != node.label) return false
        clicks += "${live.label}|${live.className.substringAfterLast('.')}"
        when (screen) {
            Screen.CALENDAR -> when {
                live.label == "Выбрать время" -> screen = Screen.PICKER
                live.desc.isNotEmpty() || live.label.matches(Regex("\\d+")) -> {
                    val d = Regex("^(\\d+)").find(live.label)!!.groupValues[1].toInt()
                    selectedDay = if (selectOffByOne) d + 1 else d
                }
            }
            Screen.PICKER -> {
                val snap = snapshot()
                val rowNode = if (snap.descendants(live.index).any { it.label.contains("–") }) live else snap.parentOf(live)
                val ivText = rowNode?.let { r -> snap.descendants(r.index).firstOrNull { it.label.contains("–") } }
                if (live.label == "Записаться") {
                    bookClicks++
                    when (resultMode) {
                        "none" -> Unit
                        else -> screen = Screen.RESULT
                    }
                } else if (ivText != null) {
                    val iv = ShiftInterval.values().first { it.label == ivText.label }
                    checked[iv] = !(checked[iv] ?: false)
                }
            }
            Screen.RESULT -> Unit
        }
        return true
    }

    fun back() {
        backs++
        if (screen == Screen.PICKER) screen = Screen.CALENDAR
    }

    companion object {
        val TODAY: LocalDate = LocalDate.of(2026, 11, 12) // четверг
        fun settings(
            auto: Boolean = true, hotOnly: Boolean = false, day: Boolean = true, night: Boolean = false,
            dry: Boolean = false, autoDays: Set<DayOfWeek> = setOf(DayOfWeek.SATURDAY)
        ) = HunterSettings(
            region = "Омск", warehouse = "Омск РФЦ", operation = "Производство непрофиль",
            dayAllowed = day, nightAllowed = night, autoEnabled = auto, hotOnly = hotOnly,
            weekdayModes = DayOfWeek.values().associateWith { if (it in autoDays) WeekdayMode.AUTO else WeekdayMode.NOTIFY },
            dryRun = dry
        )
    }
}

class MemStorage(var data: String = "") : LedgerStorage {
    override fun load() = data
    override fun save(data: String) { this.data = data }
}

/** Прогоняет машину против симулятора, исполняя её команды. */
class Harness(
    var settings: HunterSettings,
    val ozon: FakeOzon,
    val storage: MemStorage = MemStorage()
) {
    var now = 1_000_000L
    init { ozon.clock = { now } }
    val ledger = BookingLedger(storage) { now }
    val machine = HunterMachine({ settings }, ledger, { now }, { FakeOzon.TODAY })
    val notifications = ArrayList<Output.Notify>()
    val logs = ArrayList<String>()
    var probe: ColorProbe = NO_COLOR
    var failBookClick = false
    /** Состояние журнала в момент нажатия «Записаться» — должно быть ATTEMPTED (запись ДО клика). */
    var stateAtBookClick: BookingState? = null
    var ledgerKey: ShiftKey? = null

    fun step() {
        now += 800
        val outs = machine.onSnapshot(ozon.snapshot(), probe)
        for (o in outs) when (o) {
            is Output.Log -> logs += o.message
            is Output.Notify -> notifications += o
            is Output.Back -> ozon.back()
            is Output.Click -> {
                if (o.purpose.startsWith("BOOK")) stateAtBookClick = ledger.all().singleOrNull()?.state
                val ok = if (failBookClick && o.purpose.startsWith("BOOK")) false else ozon.click(o.node)
                if (!ok) for (x in machine.onClickFailed("тест")) if (x is Output.Log) logs += x.message else if (x is Output.Notify) notifications += x
            }
        }
    }

    fun run(n: Int) = repeat(n) { step() }
}
