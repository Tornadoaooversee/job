package ru.pythonlab.ozonshifthunter.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.DayOfWeek
import java.time.LocalDate

private val TODAY = FakeOzon.TODAY // четверг 12.11.2026
private val SAT = LocalDate.of(2026, 11, 14)
private val MON = LocalDate.of(2026, 11, 16)

class PolicyTests {
    private fun eval(s: HunterSettings, date: LocalDate = SAT, iv: ShiftInterval = ShiftInterval.DAY, p: Priority = Priority.RED) =
        PolicyEngine.evaluate(s, ShiftCandidate(date, iv, p), TODAY)

    @Test fun allConditionsMetAutoBooks() = assertTrue(eval(FakeOzon.settings()) is Decision.AutoBook)
    @Test fun greenAutoBooksWhenHotOnlyOff() = assertTrue(eval(FakeOzon.settings(), p = Priority.GREEN) is Decision.AutoBook)
    @Test fun yellowIgnored() = assertTrue(eval(FakeOzon.settings(), p = Priority.YELLOW) is Decision.Ignore)
    @Test fun unknownColorNeverAutoBooks() = assertTrue(eval(FakeOzon.settings(), p = Priority.UNKNOWN) is Decision.NotifyOnly)
    @Test fun disabledWeekdayIsIgnoredEvenIfAutoEnabled() {
        val s = FakeOzon.settings().copy(
            weekdayModes = FakeOzon.settings().weekdayModes + (SAT.dayOfWeek to WeekdayMode.DISABLED)
        )
        assertTrue(eval(s) is Decision.Ignore)
    }

    @Test fun disabledWeekdayIsIgnoredEvenWithUnknownColor() {
        val s = FakeOzon.settings().copy(
            weekdayModes = FakeOzon.settings().weekdayModes + (SAT.dayOfWeek to WeekdayMode.DISABLED)
        )
        assertTrue(eval(s, p = Priority.UNKNOWN) is Decision.Ignore)
    }

    @Test fun globalSwitchOffNotifiesOnly() = assertTrue(eval(FakeOzon.settings(auto = false)) is Decision.NotifyOnly)
    @Test fun notifyWeekdayNotifiesOnly() = assertTrue(eval(FakeOzon.settings(), date = MON) is Decision.NotifyOnly)
    @Test fun intervalNotSelectedIgnored() = assertTrue(eval(FakeOzon.settings(night = false), iv = ShiftInterval.NIGHT) is Decision.Ignore)
    @Test fun nightSelectedAutoBooksNight() = assertTrue(eval(FakeOzon.settings(night = true), iv = ShiftInterval.NIGHT) is Decision.AutoBook)
    @Test fun hotOnlyBlocksGreen() = assertTrue(eval(FakeOzon.settings(hotOnly = true), p = Priority.GREEN) is Decision.NotifyOnly)
    @Test fun hotOnlyAllowsRed() = assertTrue(eval(FakeOzon.settings(hotOnly = true), p = Priority.RED) is Decision.AutoBook)
    @Test fun pastDateIgnored() = assertTrue(eval(FakeOzon.settings(), date = TODAY.minusDays(1)) is Decision.Ignore)

    @Test fun userIntervalBeatsEverything() {
        // даже горящая смена в день автозаписи игнорируется, если интервал не выбран
        assertTrue(eval(FakeOzon.settings(day = false, night = true), iv = ShiftInterval.DAY, p = Priority.RED) is Decision.Ignore)
    }

    @Test fun everyWeekdayHonoursItsMode() {
        for (dow in DayOfWeek.values()) {
            val s = FakeOzon.settings(autoDays = setOf(dow))
            for (offset in 0L..6L) {
                val d = TODAY.plusDays(offset)
                val r = eval(s, date = d)
                if (d.dayOfWeek == dow) assertTrue("$d", r is Decision.AutoBook) else assertTrue("$d", r is Decision.NotifyOnly)
            }
        }
    }
}

class ColorTests {
    private fun src(argb: Int, w: Int = 100, h: Int = 100) = object : PixelSource {
        override val width = w
        override val height = h
        override fun pixel(x: Int, y: Int) = argb
    }

    @Test fun redGreenYellowNeutral() {
        assertEquals(Priority.RED, ColorClassifier.classify(0xFFE53935.toInt()))
        assertEquals(Priority.RED, ColorClassifier.classify(0xFFF91155.toInt()))
        assertEquals(Priority.GREEN, ColorClassifier.classify(0xFF43A047.toInt()))
        assertEquals(Priority.YELLOW, ColorClassifier.classify(0xFFFDD835.toInt()))
        assertEquals(Priority.UNKNOWN, ColorClassifier.classify(0xFFFFFFFF.toInt()))
        assertEquals(Priority.UNKNOWN, ColorClassifier.classify(0xFF808080.toInt()))
        assertEquals(Priority.UNKNOWN, ColorClassifier.classify(0xFF005BFF.toInt())) // фирменный синий
    }

    @Test fun regionMajority() {
        assertEquals(Priority.RED, ColorClassifier.analyzeRegion(src(0xFFE53935.toInt()), Bounds(10, 10, 90, 90)).priority)
        assertEquals(Priority.UNKNOWN, ColorClassifier.analyzeRegion(src(0xFFFFFFFF.toInt()), Bounds(10, 10, 90, 90)).priority)
    }

    @Test fun mixedRegionIsUnknown() {
        val mixed = object : PixelSource {
            override val width = 100; override val height = 100
            override fun pixel(x: Int, y: Int) = if (x < 50) 0xFFE53935.toInt() else 0xFF43A047.toInt()
        }
        // 50/50 — согласия нет → UNKNOWN, а не «угадываем»
        assertEquals(Priority.UNKNOWN, ColorClassifier.analyzeRegion(mixed, Bounds(0, 0, 100, 100)).priority)
    }

    @Test fun emptyImageIsSafe() {
        assertEquals(Priority.UNKNOWN, ColorClassifier.analyzeRegion(src(0xFFE53935.toInt(), 0, 0), Bounds(0, 0, 10, 10)).priority)
    }

    @Test fun invalidGridIsSafe() {
        assertEquals(Priority.UNKNOWN, ColorClassifier.analyzeRegion(src(0xFFE53935.toInt()), Bounds(0, 0, 10, 10), grid = 0).priority)
    }

    @Test fun fullyOutsideNegativeRegionIsUnknown() {
        assertEquals(Priority.UNKNOWN, ColorClassifier.analyzeRegion(src(0xFFE53935.toInt()), Bounds(-100, -100, -1, -1)).priority)
    }

    @Test fun boundsOutsideScreenAreSafe() {
        assertEquals(Priority.UNKNOWN, ColorClassifier.analyzeRegion(src(0xFFE53935.toInt()), Bounds(500, 500, 600, 600)).priority)
    }
}

class LedgerTests {
    private val key = ShiftKey(SAT, ShiftInterval.DAY, "Омск РФЦ", "Производство")
    private var now = 0L

    @Test fun freshKeyCanAttempt() = assertTrue(BookingLedger(MemStorage()) { now }.canAttempt(key))

    @Test fun attemptedNeverRetried() {
        val l = BookingLedger(MemStorage()) { now }
        l.markAttempted(key)
        assertFalse(l.canAttempt(key))
        now += 24 * 3600_000L
        assertFalse(l.canAttempt(key))
    }

    @Test fun bookedAndUncertainNeverRetried() {
        val l = BookingLedger(MemStorage()) { now }
        l.markBooked(key); assertFalse(l.canAttempt(key))
        l.markUncertain(key); assertFalse(l.canAttempt(key))
    }

    @Test fun failedRetriesLimitedAndDelayed() {
        val l = BookingLedger(MemStorage()) { now }
        l.markAttempted(key); l.markFailed(key)
        assertFalse(l.canAttempt(key)) // кулдаун
        now += BookingLedger.RETRY_COOLDOWN_MS
        assertTrue(l.canAttempt(key))
        l.markAttempted(key); l.markFailed(key) // вторая попытка
        now += BookingLedger.RETRY_COOLDOWN_MS * 5
        assertFalse(l.canAttempt(key)) // лимит попыток
    }

    @Test fun survivesRestart() {
        val st = MemStorage()
        BookingLedger(st) { now }.markAttempted(key)
        assertFalse(BookingLedger(st) { now }.canAttempt(key))
    }

    @Test fun garbageInStorageIsIgnored() {
        val l = BookingLedger(MemStorage("мусор\n1\t2\t3\n")) { now }
        assertTrue(l.all().isEmpty())
    }

    @Test fun activeBookingOnDate() {
        val l = BookingLedger(MemStorage()) { now }
        assertFalse(l.hasActiveBookingOn(SAT))
        l.markBooked(key)
        assertTrue(l.hasActiveBookingOn(SAT))
        assertFalse(l.hasActiveBookingOn(MON))
    }

    @Test fun notifyOnce() {
        val l = BookingLedger(MemStorage()) { now }
        assertTrue(l.canNotify(key)); l.markNotified(key); assertFalse(l.canNotify(key))
        assertTrue(l.canAttempt(key)) // уведомление не мешает последующей записи
    }

    @Test fun pruneDropsOldDates() {
        val l = BookingLedger(MemStorage()) { now }
        l.markBooked(ShiftKey(TODAY.minusDays(30), ShiftInterval.DAY, "a", "b"))
        l.markBooked(key)
        l.prune(TODAY)
        assertEquals(1, l.all().size)
    }
}

class ParserTests {
    @Test fun intervalParsing() {
        assertEquals(ShiftInterval.DAY, ScreenParser.parseInterval("08:00–20:00"))
        assertEquals(ShiftInterval.DAY, ScreenParser.parseInterval("8:00 - 20:00"))
        assertEquals(ShiftInterval.NIGHT, ScreenParser.parseInterval("с 20:00 до 08:00"))
        assertEquals(ShiftInterval.NIGHT, ScreenParser.parseInterval("20:00—8:00"))
        assertNull(ScreenParser.parseInterval("09:00–18:00"))
        assertNull(ScreenParser.parseInterval("08:30–20:00"))
    }

    @Test fun priorityFromText() {
        assertEquals(Priority.RED, ScreenParser.priorityFromText("Горящая смена"))
        assertEquals(Priority.GREEN, ScreenParser.priorityFromText("Высокая вероятность"))
        assertEquals(Priority.UNKNOWN, ScreenParser.priorityFromText("Смена"))
    }

    @Test fun calendarByDescriptions() {
        val o = FakeOzon(dayLabels = mapOf(14 to "горящая смена")); o.selectedDay = 14
        val cal = ScreenParser.parseCalendar(o.snapshot(), TODAY)
        assertNotNull(cal)
        assertEquals(30, cal!!.days.size)
        assertEquals(LocalDate.of(2026, 11, 14), cal.selectedDay?.date)
        assertNotNull(cal.timeButton)
    }

    private fun plainCalendar(selected: Int? = null): ScreenSnapshot {
        // Месяц с «хвостами» соседних месяцев: 26..31 октября и 1..6 декабря, текст — просто числа.
        val cells = ArrayList<N>()
        val seq = (26..31).map { it } + (1..30) + (1..6)
        seq.forEachIndexed { i, d ->
            val b = Bounds((i % 7) * 100, 300 + (i / 7) * 100, (i % 7) * 100 + 100, 400 + (i / 7) * 100)
            val isNov = i in 6..35
            cells += N("android.view.ViewGroup", clickable = true, selected = isNov && selected == d, bounds = b,
                children = listOf(N("android.widget.TextView", text = d.toString(), bounds = b)))
        }
        return buildSnapshot(N(children = listOf(N("android.widget.TextView", text = "Ноябрь 2026")) + cells))
    }

    @Test fun calendarFromPlainNumbersSkipsNeighbourMonths() {
        val cal = ScreenParser.parseCalendar(plainCalendar(selected = 14), TODAY)!!
        assertEquals(30, cal.days.size)
        assertEquals(LocalDate.of(2026, 11, 1), cal.days.first().date)
        assertEquals(LocalDate.of(2026, 11, 30), cal.days.last().date)
        assertEquals(LocalDate.of(2026, 11, 14), cal.selectedDay?.date)
        // кликать надо по ячейке, а не по тексту внутри
        assertTrue(cal.days.all { it.clickTarget != null && it.clickTarget!!.className.endsWith("ViewGroup") })
    }

    @Test fun notACalendarWithFewNumbers() {
        val s = buildSnapshot(N(children = listOf(N("android.widget.TextView", text = "Ноябрь 2026"), N("android.widget.TextView", text = "5"))))
        assertNull(ScreenParser.parseCalendar(s, TODAY))
    }

    @Test fun pickerParsing() {
        val o = FakeOzon(); o.screen = FakeOzon.Screen.PICKER; o.checked[ShiftInterval.NIGHT] = true
        val p = ScreenParser.parsePicker(o.snapshot())!!
        assertEquals(2, p.options.size)
        val day = p.options.first { it.interval == ShiftInterval.DAY }
        val night = p.options.first { it.interval == ShiftInterval.NIGHT }
        assertEquals(false, day.checked)
        assertEquals(true, night.checked)
        assertNotNull(day.toggle)
        assertNotNull(p.bookButton)
    }

    @Test fun singleOptionPickerDoesNotSwallowWholeScreen() {
        val o = FakeOzon(intervals = listOf(ShiftInterval.DAY)); o.screen = FakeOzon.Screen.PICKER
        val p = ScreenParser.parsePicker(o.snapshot())!!
        assertEquals(1, p.options.size)
        assertEquals(false, p.options[0].checked)
    }

    @Test fun classification() {
        val o = FakeOzon()
        assertEquals(ScreenType.CALENDAR, ScreenParser.classify(o.snapshot()))
        o.screen = FakeOzon.Screen.PICKER
        assertEquals(ScreenType.TIME_PICKER, ScreenParser.classify(o.snapshot()))
        o.calendarUnderSheet = true // календарь под шторкой → всё равно выбор времени
        assertEquals(ScreenType.TIME_PICKER, ScreenParser.classify(o.snapshot()))
        o.screen = FakeOzon.Screen.RESULT
        assertEquals(ScreenType.UNKNOWN, ScreenParser.classify(o.snapshot()))
        assertEquals(ScreenType.NOT_OZON, ScreenParser.classify(buildSnapshot(N(), pkg = "com.android.chrome")))
    }

    @Test fun resultDetection() {
        fun r(t: String) = ScreenParser.detectResult(buildSnapshot(N(children = listOf(N(text = t)))))
        assertEquals(BookingResult.SUCCESS, r("Вы записаны на смену"))
        assertEquals(BookingResult.ERROR, r("Не удалось записаться"))
        assertNull(r("Выберите время"))
        assertNull(r("Вы не записаны"))
        val toast = buildSnapshot(N(), extra = listOf("Запись подтверждена"))
        assertEquals(BookingResult.SUCCESS, ScreenParser.detectResult(toast))
    }

    @Test fun contextConfirmation() {
        val o = FakeOzon()
        assertTrue(ScreenParser.contextConfirmed(o.snapshot(), FakeOzon.settings()))
        o.warehouse = "Другой склад"
        assertFalse(ScreenParser.contextConfirmed(o.snapshot(), FakeOzon.settings()))
        assertFalse(ScreenParser.contextConfirmed(o.snapshot(), FakeOzon.settings().copy(operation = "")))
    }
}

class MachineTests {
    private fun hot14() = FakeOzon(dayLabels = mapOf(14 to "горящая смена", 13 to "низкая вероятность", 17 to "высокая вероятность"))

    private fun Harness.bookClicks() = ozon.bookClicks

    @Test fun dryRunNeverClicksAnything() {
        val h = Harness(FakeOzon.settings(dry = true), hot14())
        h.run(40)
        assertEquals(0, h.ozon.clicks.size)
        assertEquals(0, h.ozon.backs)
        assertEquals(HunterMachine.Phase.IDLE, h.machine.phase)
    }

    @Test fun dryRunUserDrivenFlowNotifiesButNeverBooks() {
        val o = hot14()
        val h = Harness(FakeOzon.settings(dry = true), o)
        o.selectedDay = 14            // пользователь сам выбрал день...
        h.step()                       // машина видит календарь
        o.screen = FakeOzon.Screen.PICKER // ...и сам открыл выбор времени
        h.step(); h.step()
        assertEquals(0, o.clicks.size)
        assertTrue(h.notifications.isNotEmpty())
        assertEquals(0, o.bookClicks)
    }

    @Test fun activeFlowBooksExactlyOnceAndConfirms() {
        val h = Harness(FakeOzon.settings(), hot14())
        h.run(60)
        assertEquals(1, h.ozon.bookClicks)
        val key = ShiftKey(SAT, ShiftInterval.DAY, "Омск РФЦ", "Производство непрофиль")
        assertEquals(BookingState.BOOKED, h.ledger.state(key))
        assertTrue(h.notifications.any { it.title.contains("Записан") })
        // дальше хоть 200 снимков — повторных нажатий нет
        h.run(200)
        assertEquals(1, h.ozon.bookClicks)
    }

    @Test fun ledgerIsWrittenBeforeBookClick() {
        val h = Harness(FakeOzon.settings(), hot14())
        h.run(60)
        assertEquals(BookingState.ATTEMPTED, h.stateAtBookClick)
    }

    @Test fun otherIntervalAlreadyCheckedBlocksBooking() {
        val o = hot14()
        o.checked[ShiftInterval.NIGHT] = true // пользователь/приложение уже отметили ночную смену
        val h = Harness(FakeOzon.settings(), o) // а разрешён только день
        h.run(100)
        assertEquals(0, o.bookClicks)
        assertTrue(h.logs.any { it.contains("другой интервал") })
    }

    @Test fun checksDayBeforeBook() {
        val h = Harness(FakeOzon.settings(), hot14())
        h.run(60)
        // порядок: день 14 → «Выбрать время» → галочка → «Записаться»
        val c = h.ozon.clicks
        assertTrue(c.first().startsWith("14 ноября"))
        assertTrue(c.indexOfFirst { it.startsWith("Выбрать время") } in 1 until c.indexOfFirst { it.startsWith("Записаться") })
    }

    @Test fun yellowDayIsNeverVisited() {
        val h = Harness(FakeOzon.settings(), hot14())
        h.run(80)
        assertFalse(h.ozon.clicks.any { it.startsWith("13 ноября") })
    }

    @Test fun greenNotBookedWhenHotOnly() {
        val o = FakeOzon(dayLabels = mapOf(14 to "высокая вероятность"))
        val h = Harness(FakeOzon.settings(hotOnly = true), o)
        h.run(60)
        assertEquals(0, o.bookClicks)
        assertTrue(h.notifications.isNotEmpty()) // зато уведомление есть
    }

    @Test fun notifyWeekdayNeverBooks() {
        val o = FakeOzon(dayLabels = mapOf(15 to "горящая смена")) // воскресенье
        val h = Harness(FakeOzon.settings(), o)
        h.run(60)
        assertEquals(0, o.bookClicks)
        assertTrue(h.notifications.any { it.text.contains("Только уведомление") })
    }

    @Test fun globalSwitchOffNeverBooks() {
        val h = Harness(FakeOzon.settings(auto = false), hot14())
        h.run(60)
        assertEquals(0, h.ozon.bookClicks)
    }

    @Test fun unknownColorNeverBooks() {
        val h = Harness(FakeOzon.settings(), FakeOzon()) // ни одной подписи, цвет не определяется
        h.run(120)
        assertEquals(0, h.ozon.bookClicks)
    }

    @Test fun colorFromScreenshotProbeIsUsed() {
        val h = Harness(FakeOzon.settings(), FakeOzon())
        // красим 14-е число красным через пробу по координатам ячейки (pos=13 → col 6? считаем из bounds)
        val offset = 6 // 1 ноября 2026 — воскресенье
        val pos = offset + 14 - 1
        val cell = Bounds((pos % 7) * 100, 300 + (pos / 7) * 100, (pos % 7) * 100 + 100, 400 + (pos / 7) * 100)
        // Машина снимает цвет только с зоны индикатора: верхние 38% и правые 42% ячейки (см. dayPriority).
        val b = Bounds(cell.left + cell.width * 58 / 100, cell.top, cell.right, cell.top + cell.height * 38 / 100)
        h.probe = { bb -> if (bb == b) ColorAnalysis(Priority.RED, 0xFFE53935.toInt(), 1.0) else ColorAnalysis(Priority.UNKNOWN, null, 0.0) }
        h.run(80)
        assertEquals(1, h.ozon.bookClicks)
        assertEquals(SAT.dayOfMonth, h.ozon.clicks.first().substringBefore(' ').toInt())
    }

    @Test fun contextNotConfirmedMeansNoClicks() {
        val o = hot14(); o.warehouse = "Чужой склад"
        val h = Harness(FakeOzon.settings(), o)
        h.run(60)
        assertEquals(0, o.clicks.size)
    }

    @Test fun selectionNotObservableAbortsBeforeBooking() {
        val o = hot14(); o.exposeSelected = false
        val h = Harness(FakeOzon.settings(), o)
        h.run(80)
        assertEquals(0, o.bookClicks)
        assertTrue(h.logs.any { it.contains("SELECTION_UNVERIFIABLE") })
    }

    @Test fun wrongDaySelectedAbortsBeforeBooking() {
        val o = hot14(); o.selectOffByOne = true
        val h = Harness(FakeOzon.settings(), o)
        h.run(80)
        assertEquals(0, o.bookClicks)
        assertTrue(h.logs.any { it.contains("а нужен") })
    }

    @Test fun checkboxNotReflectingStateAbortsBeforeBooking() {
        val o = hot14(); o.exposeChecked = false
        val h = Harness(FakeOzon.settings(), o)
        h.run(100)
        assertEquals(0, o.bookClicks)
    }

    @Test fun disabledBookButtonNotClicked() {
        val o = hot14(); o.bookEnabled = false
        val h = Harness(FakeOzon.settings(), o)
        h.run(80)
        assertEquals(0, o.bookClicks)
    }

    @Test fun unconfirmedResultBecomesUncertainAndIsNeverRetried() {
        val o = hot14(); o.resultMode = "none"
        val h = Harness(FakeOzon.settings(), o)
        h.run(300)
        assertEquals(1, o.bookClicks)
        val key = ShiftKey(SAT, ShiftInterval.DAY, "Омск РФЦ", "Производство непрофиль")
        assertEquals(BookingState.UNCERTAIN, h.ledger.state(key))
        assertTrue(h.notifications.any { it.title.contains("вручную") })
    }

    @Test fun errorResultMarksFailedAndDoesNotImmediatelyRetry() {
        val o = hot14(); o.resultMode = "error"
        val h = Harness(FakeOzon.settings(), o)
        h.run(100)
        assertEquals(1, o.bookClicks)
        val key = ShiftKey(SAT, ShiftInterval.DAY, "Омск РФЦ", "Производство непрофиль")
        assertEquals(BookingState.FAILED, h.ledger.state(key))
    }

    @Test fun failedBookClickIsNotRepeatedImmediately() {
        val h = Harness(FakeOzon.settings(), hot14())
        h.failBookClick = true
        h.run(100)
        assertEquals(0, h.ozon.bookClicks)
        val key = ShiftKey(SAT, ShiftInterval.DAY, "Омск РФЦ", "Производство непрофиль")
        // С 0.3.8: отказ performAction не доказывает, что запись не ушла → UNCERTAIN, повтор заблокирован.
        assertEquals(BookingState.UNCERTAIN, h.ledger.state(key))
    }

    @Test fun alreadyBookedKeyIsNotBookedAgainAfterRestart() {
        val st = MemStorage()
        val h1 = Harness(FakeOzon.settings(), hot14(), st)
        h1.run(60)
        assertEquals(1, h1.ozon.bookClicks)
        // «перезапуск приложения»: новый ledger/machine на тех же данных, интерфейс снова в начале
        val h2 = Harness(FakeOzon.settings(), hot14(), st)
        h2.run(200)
        assertEquals(0, h2.ozon.bookClicks)
    }

    @Test fun secondIntervalSameDateNotBookedAfterFirst() {
        val o = FakeOzon(dayLabels = mapOf(14 to "горящая смена"))
        val h = Harness(FakeOzon.settings(night = true), o)
        h.run(300)
        assertEquals(1, o.bookClicks)
    }

    @Test fun settingsChangedToDryRunMidFlowStopsClicking() {
        val o = hot14()
        val h = Harness(FakeOzon.settings(), o)
        h.run(3)
        h.settings = FakeOzon.settings(dry = true)
        val before = o.clicks.size
        h.run(80)
        assertEquals(before, o.clicks.size)
        assertEquals(0, o.bookClicks)
    }

    @Test fun leavingOzonAbortsFlow() {
        val o = hot14()
        val h = Harness(FakeOzon.settings(), o)
        h.run(3)
        h.machine.onSnapshot(buildSnapshot(N(), pkg = "com.android.chrome"))
        assertEquals(HunterMachine.Phase.IDLE, h.machine.phase)
    }

    @Test fun calendarUnderSheetStillBooksOnce() {
        val o = hot14(); o.calendarUnderSheet = true
        val h = Harness(FakeOzon.settings(), o)
        h.run(100)
        assertEquals(1, o.bookClicks)
    }

    @Test fun otherAppsNeverInspected() {
        val h = Harness(FakeOzon.settings(), hot14())
        val outs = h.machine.onSnapshot(buildSnapshot(N(children = listOf(N(text = "секретное сообщение"))), pkg = "org.telegram.messenger"))
        assertTrue(outs.none { it is Output.Click })
        assertTrue(outs.filterIsInstance<Output.Log>().none { it.message.contains("секретное") })
    }
}

class DumpTests {
    @Test fun dumpContainsLabelsStatesAndBounds() {
        val o = FakeOzon(dayLabels = mapOf(14 to "горящая смена")); o.selectedDay = 14
        val lines = ScreenDump.lines(o.snapshot())
        assertTrue(lines.any { it.contains("desc=\"14 ноября, горящая смена\"") && it.contains("sel=true") && it.contains("b=") })
        assertTrue(lines.any { it.contains("text=\"Выбрать время\"") && it.contains("clk=true") })
    }

    @Test fun signatureChangesWithState() {
        val o = FakeOzon(); o.screen = FakeOzon.Screen.PICKER
        val a = ScreenDump.signature(o.snapshot())
        o.checked[ShiftInterval.DAY] = true
        assertTrue(a != ScreenDump.signature(o.snapshot()))
    }

    @Test fun dumpIsBounded() {
        val big = buildSnapshot(N(children = (1..1000).map { N(text = "t$it") }))
        assertTrue(ScreenDump.lines(big).size <= ScreenDump.MAX_LINES + 1)
    }
}


/** Regression cases derived from the supplied Ozon Job picker and confirmation screenshots. */
class WaitlistRegressionTests {
    private fun snapshot(vararg labels: String) = ScreenSnapshot(
        "ru.ozon.job", emptyList(), 0L, labels.toList()
    )

    @Test fun pickerQueueLabelIsNotAcceptance() {
        assertNull(ScreenParser.detectResult(snapshot("ОЧЕРЕДЬ", "Запись в очереди, за 24 часа сообщим о её статусе", "Записаться")))
    }

    @Test fun acceptedQueueIsSeparateFromConfirmed() {
        assertEquals(BookingResult.WAITLISTED, ScreenParser.detectResult(snapshot("Вы добавлены в очередь")))
        assertEquals(BookingResult.SUCCESS, ScreenParser.detectResult(snapshot("Запись подтверждена", "Ждём вас на складе")))
    }

    @Test fun waitlistCannotBeBookedAgain() {
        val storage = object : LedgerStorage {
            var data = ""
            override fun load() = data
            override fun save(data: String) { this.data = data }
        }
        val ledger = BookingLedger(storage) { 100000L }
        val key = ShiftKey(LocalDate.of(2026, 12, 1), ShiftInterval.NIGHT, "Омск РФЦ", "Подбор")
        ledger.markAttempted(key)
        ledger.markWaitlisted(key)
        assertEquals(BookingState.WAITLISTED, ledger.state(key))
        assertFalse(ledger.canAttempt(key))
        assertTrue(ledger.hasActiveBookingOn(key.date))
        assertEquals(BookingState.WAITLISTED, BookingLedger(storage) { 200000L }.state(key))
    }

    @Test fun whitePriorityIsDistinctAndAllowedByPolicy() {
        assertEquals(2, Priority.WHITE.rank)
        val settings = FakeOzon.settings()
        val result = PolicyEngine.evaluate(settings, ShiftCandidate(LocalDate.of(2026, 11, 14), ShiftInterval.DAY, Priority.WHITE), FakeOzon.TODAY)
        assertTrue(result is Decision.AutoBook)
        assertEquals(Priority.UNKNOWN, ColorClassifier.classify(0xFFFFFFFF.toInt()))
    }
}


/** Safe status transitions and screenshot-derived queue wording. */
class QueueStatus034Tests {
    private fun snap(vararg labels: String) = ScreenSnapshot("ru.ozon.job", emptyList(), 0L, labels.toList())

    @Test fun queueExplanationInPickerDoesNotMeanAccepted() {
        assertNull(ScreenParser.detectResult(snap("ОЧЕРЕДЬ", "Запись в очереди, за 24 часа сообщим о её статусе")))
    }

    @Test fun explicitAcceptanceDoesMeanWaitlisted() {
        assertEquals(BookingResult.WAITLISTED, ScreenParser.detectResult(snap("Вы поставлены в очередь")))
        assertEquals(BookingResult.WAITLISTED, ScreenParser.detectResult(snap("Вы добавлены в очередь")))
    }

    @Test fun onlyWaitlistedCanTransitionToConfirmed() {
        val storage = object : LedgerStorage {
            var value = ""
            override fun load() = value
            override fun save(data: String) { value = data }
        }
        val ledger = BookingLedger(storage) { 123456L }
        val key = ShiftKey(LocalDate.of(2026, 12, 1), ShiftInterval.DAY, "Омск РФЦ", "Подбор")
        assertFalse(ledger.confirmWaitlisted(key))
        ledger.markAttempted(key)
        assertFalse(ledger.confirmWaitlisted(key))
        ledger.markWaitlisted(key)
        assertFalse(ledger.observeWaitlist(key, confirmed = false))
        assertEquals(BookingState.WAITLISTED, ledger.state(key))
        assertTrue(ledger.observeWaitlist(key, confirmed = true))
        assertEquals(BookingState.BOOKED, ledger.state(key))
        assertFalse(ledger.confirmWaitlisted(key))
        assertFalse(ledger.canAttempt(key))
        assertEquals(1, ledger.attempts(key))
        assertEquals(BookingState.BOOKED, BookingLedger(storage) { 123457L }.state(key))
    }
}


class RegionContextTests {
    private fun screen(vararg labels: String): ScreenSnapshot = ScreenSnapshot(
        packageName = "ru.ozon.job",
        nodes = labels.mapIndexed { i, label ->
            UiNode(index = i, parent = -1, depth = 0, path = listOf(i), text = label)
        },
        timeMs = 0L
    )

    @Test fun configuredRegionMustBeVisible() {
        val settings = HunterSettings(region = "Омск", warehouse = "РФЦ", operation = "Возвраты")
        assertFalse(ScreenParser.contextConfirmed(screen("РФЦ", "Возвраты"), settings))
    }

    @Test fun visibleRegionWarehouseAndOperationAreConfirmed() {
        val settings = HunterSettings(region = "Омск", warehouse = "Омск РФЦ", operation = "Возвраты")
        assertTrue(ScreenParser.contextConfirmed(screen("Омск РФЦ", "Возвраты"), settings))
    }

    @Test fun wrongRegionCannotPassEvenIfWarehouseAndOperationMatch() {
        val settings = HunterSettings(region = "Тула", warehouse = "Омск РФЦ", operation = "Возвраты")
        assertFalse(ScreenParser.contextConfirmed(screen("Омск РФЦ", "Возвраты"), settings))
    }
}


/** Регрессии: не подтверждаем запись по старому позитивному тексту рядом с ошибкой. */
class ResultSafety036Tests {
    private fun snap(vararg labels: String): ScreenSnapshot = ScreenSnapshot(
        "ru.ozon.job", labels.mapIndexed { i, label -> UiNode(index = i, parent = -1, depth = 0, path = listOf(i), text = label) }, 0L
    )

    @Test fun errorOverridesOldSuccess() = assertEquals(
        BookingResult.ERROR,
        ScreenParser.detectResult(snap("Запись подтверждена", "Не удалось записаться, попробуйте позже"))
    )

    @Test fun acceptedWaitlistIsNotBooked() = assertEquals(
        BookingResult.WAITLISTED,
        ScreenParser.detectResult(snap("Вы добавлены в очередь"))
    )

    @Test fun mereQueueLabelIsNotAcceptance() = assertNull(
        ScreenParser.detectResult(snap("ОЧЕРЕДЬ"))
    )
}


class ResultSafety037Tests {
    private fun snap(vararg labels: String, truncated: Boolean = false) =
        ScreenSnapshot("ru.ozon.job", emptyList(), 1L, labels.toList(), truncated)

    @org.junit.Test fun cancellationOverridesOldSuccess() {
        org.junit.Assert.assertEquals(BookingResult.ERROR,
            ScreenParser.detectResult(snap("Запись подтверждена", "Запись отменена")))
    }

    @org.junit.Test fun rejectedQueueIsNotAccepted() {
        org.junit.Assert.assertEquals(BookingResult.ERROR,
            ScreenParser.detectResult(snap("Вы добавлены в очередь", "Заявка отклонена")))
    }

    @org.junit.Test fun truncatedTreeCannotConfirmBooking() {
        org.junit.Assert.assertNull(ScreenParser.detectResult(snap("Запись подтверждена", truncated = true)))
    }
}


/** 0.3.8: a failed performAction is not proof of failed server-side booking. */
class ResultSafety038Tests {
    private class Mem : LedgerStorage {
        var value = ""
        override fun load(): String = value
        override fun save(data: String) { value = data }
    }

    @org.junit.Test fun ambiguousBookingClickRemainsLocked() {
        val ledger = BookingLedger(Mem()) { 1_000L }
        val key = ShiftKey(java.time.LocalDate.of(2026, 12, 1), ShiftInterval.DAY, "Омск РФЦ", "Подбор")
        ledger.markAttempted(key)
        ledger.markUncertain(key)
        org.junit.Assert.assertEquals(BookingState.UNCERTAIN, ledger.state(key))
        org.junit.Assert.assertFalse(ledger.canAttempt(key))
        org.junit.Assert.assertEquals(1, ledger.attempts(key))
    }
}


/** 0.3.9: результат должен принадлежать Ozon, а отрицание очереди не подтверждает заявку. */
class ResultSafety039Tests {
    private fun snap(pkg: String, vararg labels: String): ScreenSnapshot = ScreenSnapshot(
        pkg, labels.mapIndexed { i, t -> UiNode(index = i, parent = -1, depth = 0, path = listOf(i), text = t) }, 100L
    )

    @org.junit.Test fun foreignAppCannotConfirmBooking() {
        org.junit.Assert.assertNull(ScreenParser.detectResult(snap("com.example.messages", "Запись подтверждена")))
    }

    @org.junit.Test fun notInQueueIsNotWaitlisted() {
        org.junit.Assert.assertEquals(BookingResult.ERROR,
            ScreenParser.detectResult(snap("ru.ozon.job", "Вы не в очереди")))
    }

    @org.junit.Test fun acceptedQueueStillRecognized() {
        org.junit.Assert.assertEquals(BookingResult.WAITLISTED,
            ScreenParser.detectResult(snap("ru.ozon.job", "Вы добавлены в очередь")))
    }
}


class OperationContextTests {
    private fun snapWith(vararg texts: String) =
        buildSnapshot(N(children = texts.map { N("android.widget.TextView", text = it) }))
    private fun st(op: String) = HunterSettings(operation = op)

    @Test fun exactOperationConfirmed() = assertTrue(ScreenParser.contextConfirmed(snapWith("Подбор"), st("Подбор")))

    @Test fun shorterOperationIsNotConfirmedByLongerOne() {
        assertFalse(ScreenParser.contextConfirmed(snapWith("Подбор возвратов"), st("Подбор")))
        assertTrue(ScreenParser.contextConfirmed(snapWith("Подбор возвратов"), st("Подбор возвратов")))
    }

    @Test fun operationInsideLongerHeaderStillConfirmed() =
        assertTrue(ScreenParser.contextConfirmed(snapWith("Омск РФЦ · Подбор"), st("Подбор")))

    @Test fun differentOperationNotConfirmed() =
        assertFalse(ScreenParser.contextConfirmed(snapWith("Упаковка"), st("Подбор")))

    @Test fun yoIsNormalized() = assertTrue(ScreenParser.contextConfirmed(snapWith("Приёмка"), st("Приемка")))

    @Test fun listHasSixteenUniqueOperations() {
        assertEquals(16, KnownOperations.ALL.size)
        assertEquals(16, KnownOperations.ALL.map { normalize(it) }.toSet().size)
    }
}
