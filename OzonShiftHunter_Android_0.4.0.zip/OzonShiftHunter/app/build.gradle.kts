plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "ru.pythonlab.ozonshifthunter"
    compileSdk = 35
    defaultConfig {
        applicationId = "ru.pythonlab.ozonshifthunter"
        minSdk = 26
        targetSdk = 35
        versionCode = 14
        versionName = "0.4.0"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    // Тесты чистого ядра (core/): ./gradlew :app:testDebugUnitTest
    testImplementation("junit:junit:4.13.2")
}
